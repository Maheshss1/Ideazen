package com.mahesh.ideazenhackathon;

import com.mahesh.ideazenhackathon.model.Project;

public interface OnClickListener {
    void onClick(Project project, int position);
}
